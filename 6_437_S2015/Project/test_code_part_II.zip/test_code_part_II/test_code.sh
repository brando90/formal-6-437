unzip upload.zip -d ./to_be_removed
add matlab
matlab -ver 8.5 -nodisplay -nosplash -r "matlab_wrapper; exit;"
rm -rf ./to_be_removed
